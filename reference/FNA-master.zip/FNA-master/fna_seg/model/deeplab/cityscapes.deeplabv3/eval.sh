#!/usr/bin/env sh

python eval.py --checkpoint ./ --net_config ./net_config --data_path ./cityscapes