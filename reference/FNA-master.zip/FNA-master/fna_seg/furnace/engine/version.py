#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2018/8/3 下午2:59
# @Author  : yuchangqian
# @Contact : changqian_yu@163.com
# @File    : version.py

__version__ = '0.1.1'