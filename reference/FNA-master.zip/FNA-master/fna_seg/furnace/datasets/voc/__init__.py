from .voc import VOC

__all__ = ['VOC']