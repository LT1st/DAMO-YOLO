from .camvid import CamVid

__all__ = ['CamVid']