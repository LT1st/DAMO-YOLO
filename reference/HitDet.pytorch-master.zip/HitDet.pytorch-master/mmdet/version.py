# GENERATED VERSION FILE
# TIME: Sun Aug 18 00:41:58 2019

__version__ = '0.6.0+unknown'
short_version = '0.6.0'
