## Score module

***
### **MadNAS Score**:
The version of mathematical formula calculation, which does not need forward on GPU and has very fast speed.

***
### **DeepMad Score**:
The version of mathematical formula calculation, which does not need forward on GPU and has very fast speed.

### **Random Score**:
Random generated scores for debug.

### **Ensemble Score**:
Calculate combinated score of multiple score_type with ratio.


### **STEntr Score**:
Calculate spatio-temporal entropy score.
