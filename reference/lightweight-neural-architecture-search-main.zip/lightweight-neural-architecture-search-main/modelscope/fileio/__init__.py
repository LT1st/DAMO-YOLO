# Copyright (c) Alibaba, Inc. and its affiliates.

from .file import File, LocalStorage
from .io import dump, dumps, load
